package com.example.demo.model;

public class Biodata {
	private String nik;
	private String nama;
	private String alamat;
	private int id_salary;
	
	public String getNik() {
		return nik;
	}
	public void setNik(String nik) {
		this.nik = nik;
	}
	public String getNama() {
		return nama;
	}
	public void setNama(String nama) {
		this.nama = nama;
	}
	public String getAlamat() {
		return alamat;
	}
	public void setAlamat(String alamat) {
		this.alamat = alamat;
	}
	public int getId_salary() {
		return id_salary;
	}
	public void setId_salary(int id_salary) {
		this.id_salary = id_salary;
	}
}
