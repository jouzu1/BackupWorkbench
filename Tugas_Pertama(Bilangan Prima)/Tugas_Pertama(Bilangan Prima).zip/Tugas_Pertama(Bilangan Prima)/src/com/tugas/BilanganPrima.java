package com.tugas;

import java.util.Scanner;

public class BilanganPrima {
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int uji_prima = 0;
		System.out.println("Tugas Bilangan Prima");
		
		System.out.println("===============================================");
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Masukkan Angkanya : ");
		
		int angka = scan.nextInt();

			if(angka == 1) 
			{
				System.out.println("--> "+angka + " Bukanlah Angka Prima");
			}else if (angka == 2) 
			{
				System.out.println("--> "+angka + " Merupakan Angka Prima");
			}
			else if(angka % 2 == 0) 
			{
				System.out.println("--> "+angka + " Bukanlah Angka Prima");
			}
			else if (angka % 2 == 1 || angka == 2)
			{
				System.out.println("--> "+angka + " Merupakan Angka Prima");
			}
	}
}
