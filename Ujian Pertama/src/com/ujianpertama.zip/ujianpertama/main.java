package com.ujianpertama;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MenggambarDenganJava ukuran = new MenggambarDenganJava(5);
//		ukuran.GambarKotak();
//		ukuran.GambarSegitiga();
//		ukuran.GambarSegitigaTerbalik();
//		ukuran.GambarSelangSeling();
		ukuran.GambarCampur();
//		ukuran.GabungGambar("campur","selang seling");
	}
}
